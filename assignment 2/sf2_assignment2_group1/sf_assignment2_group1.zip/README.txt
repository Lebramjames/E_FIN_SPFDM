Contents Overview:
- PDF version of Assignment 2 Jupyter File: A complete, static PDF version of our Jupyter notebook.
- Jupyter version of Assignment 2: The interactive .ipynb file with all our work.
- Folder: Sources - Classes/Models: Contains key classes used in our analysis:
    bacheliermodel
    bivariateMonteCarlo
    blackscholesmodel
    distribution_test (for checking if a model follows a log/normal distribution)
    plotter
- Folder: Plotter - containing all the plots made for question a

We appreciate your time reviewing our work. We've put our best efforts into maintaining good coding practices throughout this project.